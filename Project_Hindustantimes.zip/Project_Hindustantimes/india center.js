//imp this is entire one section like in pic

var h4 = document.createElement("h4")
h4.innerText = "INDIA NEWS"
h4.setAttribute("class","main_heading")
document.querySelector("#center").append(h4)


 
//   one sub div created
var arr1 =[]         //subdiv right 
var right_side = {
heading: "Evening brief: Maharashtra is peaceful, says Sanjay Raut on loudspeaker row",
image:"https://images.hindustantimes.com/img/2022/05/07/550x309/a8236188-cac3-11ec-8ffc-07511f5657a1_1651571074549_1651922371531.jpg",
date_time:"Published on May 07, 2022 03:14 PM IST"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")
    

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
    
    var h3 = document.createElement("h3")
    h3.innerText = "INDIA NEWS"
    h3.style.color = "#00b1cd"
    

    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
    p.setAttribute("class","center_heading")

  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
    
    
    var p1 = document.createElement("p")
    p1.innerText = ele.date_time
    p1.style.color = "#757575"
  
    right_side_subdiv.append(h3,p,img,p1)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#center").append(right_side_div)
  })
                //--------------------
                var arr1 =[]         //subdiv right 
                var right_side = {
                heading: "'Heart-wrenching… very sad': PM Modi grieves over Mathura, Indore tragedies",
                image:"https://images.hindustantimes.com/img/2022/05/07/550x309/ANI-20220505131-0_1651911962301_1651911971130.jpg",
                date_time:"Published on May 07, 2022 03:14 PM IST"
                };
                arr1.push(right_side)
                
                arr1.forEach(function (ele){
                    var right_side_div = document.createElement("div")
                    right_side_div.setAttribute("class","maindiv_shadow")
                    
                
                    var right_side_subdiv = document.createElement("div")
                    right_side_subdiv.setAttribute("class","div_shadow")
                    
                    var h3 = document.createElement("h3")
                    h3.innerText = "DELHI NEWS"
                    h3.style.color = "#00b1cd"
                
                    var p = document.createElement("p")
                    p.innerText = ele.heading
                    p.setAttribute("class","latest_news_heading")
                    p.setAttribute("class","center_heading")
                
                  
                    var img = document.createElement("img")
                    img.setAttribute("src",ele.image) 
                    img.setAttribute("class","right_1_big_img")
                    
                    
                    var p1 = document.createElement("p")
                    p1.innerText = ele.date_time
                    p1.style.color = "#757575"
                  
                    right_side_subdiv.append(h3,p,img,p1)
                    right_side_div.append(right_side_subdiv)
                    document.querySelector("#center").append(right_side_div)
                  })

                  var arr1 =[]         //subdiv right 
var right_side = {
heading: "Banned ULFA-I ‘executes’ 2 cadres in Assam on charges of spying for police",
image:"https://images.hindustantimes.com/img/2022/05/07/550x309/536e84b0-cde3-11ec-a46f-a29bd7e5e767_1651913713781.jpg",
date_time:"Published on May 07, 2022 03:14 PM IST"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")
    

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
    
    var h3 = document.createElement("h3")
    h3.innerText = "CRICKET NEWS"
    h3.style.color = "#00b1cd"

    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
    p.setAttribute("class","center_heading")

  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
    
    
    var p1 = document.createElement("p")
    p1.innerText = ele.date_time
    p1.style.color = "#757575"
  
    right_side_subdiv.append(h3,p,img,p1)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#center").append(right_side_div)
  })
  var arr1 =[]         //subdiv right 
var right_side = {
heading: "Tap tech for border roads: Rajnath Singh to BRO, cites Chinese infra across LAC",
image:"https://images.hindustantimes.com/img/2022/05/07/550x309/df9df686-cde9-11ec-a46f-a29bd7e5e767_1651916653823.jpg",
date_time:"Published on May 07, 2022 03:14 PM IST"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")
    

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
    
    var h3 = document.createElement("h3")
    h3.innerText = "INDIA NEWS"
    h3.style.color = "#00b1cd"

    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
    p.setAttribute("class","center_heading")

  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
    
    
    var p1 = document.createElement("p")
    p1.innerText = ele.date_time
    p1.style.color = "#757575"
  
    right_side_subdiv.append(h3,p,img,p1)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#center").append(right_side_div)
  })

 //----------==============------------------one category done

 var h4 = document.createElement("h4")
h4.innerText = "DON'T MISS"
h4.setAttribute("class","main_heading")
document.querySelector("#center").append(h4)


 
//   one sub div created
var arr1 =[]         //subdiv right 
var right_side = {
heading: "India’s daily Covid tally above 3,500-mark again: Top 10 updates",
image:"https://images.hindustantimes.com/img/2022/05/06/550x309/gurugram-coronavirus-testing_d545fd18-dc1f-11ea-a145-8bf15479dae6_1651808242969.jpg",
date_time:"Published on May 07, 2022 03:14 PM IST"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")
    

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
    
    var h3 = document.createElement("h3")
    h3.innerText = "INDIA NEWS"
    h3.style.color = "#00b1cd"

    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
    p.setAttribute("class","center_heading")

  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
    
    
    var p1 = document.createElement("p")
    p1.innerText = ele.date_time
    p1.style.color = "#757575"
  
    right_side_subdiv.append(h3,p,img,p1)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#center").append(right_side_div)
  })
                //--------------------
                var arr1 =[]         //subdiv right 
                var right_side = {
                heading: "Cyclone likely to miss Odisha-Andhra coast, set to change course on May 10",
                image:"https://images.hindustantimes.com/img/2022/05/07/550x309/650bcc60-cdfb-11ec-a18e-026abbb3bb32_1651924454287.jpg",
                date_time:"Published on May 07, 2022 03:14 PM IST"
                };
                arr1.push(right_side)
                
                arr1.forEach(function (ele){
                    var right_side_div = document.createElement("div")
                    right_side_div.setAttribute("class","maindiv_shadow")
                    
                
                    var right_side_subdiv = document.createElement("div")
                    right_side_subdiv.setAttribute("class","div_shadow")
                    
                    var h3 = document.createElement("h3")
                    h3.innerText = "DELHI NEWS"
                    h3.style.color = "#00b1cd"
                
                    var p = document.createElement("p")
                    p.innerText = ele.heading
                    p.setAttribute("class","latest_news_heading")
                    p.setAttribute("class","center_heading")
                
                  
                    var img = document.createElement("img")
                    img.setAttribute("src",ele.image) 
                    img.setAttribute("class","right_1_big_img")
                    
                    
                    var p1 = document.createElement("p")
                    p1.innerText = ele.date_time
                    p1.style.color = "#757575"
                  
                    right_side_subdiv.append(h3,p,img,p1)
                    right_side_div.append(right_side_subdiv)
                    document.querySelector("#center").append(right_side_div)
                  })

                  var arr1 =[]         //subdiv right 
var right_side = {
heading: "Supreme Court gets a full house as Centre clears elevation of 2 new judges",
image:"https://images.hindustantimes.com/img/2022/05/07/550x309/43042e5c-cdef-11ec-a46f-a29bd7e5e767_1651918933829.jpg",
date_time:"Published on May 07, 2022 03:14 PM IST"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")
    

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
    
    var h3 = document.createElement("h3")
    h3.innerText = "INDIA NEWS"
    h3.style.color = "#00b1cd"

    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
    p.setAttribute("class","center_heading")

  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
    
    
    var p1 = document.createElement("p")
    p1.innerText = ele.date_time
    p1.style.color = "#757575"
  
    right_side_subdiv.append(h3,p,img,p1)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#center").append(right_side_div)
  })
  var arr1 =[]         //subdiv right 
var right_side = {
heading: "Rahul Gandhi says, 'We want to hear everyone's voice, but not in media'",
image:"https://images.hindustantimes.com/img/2022/05/07/550x309/rahul_telangana_1651918584508_1651918594001.jpg",
date_time:"Published on May 07, 2022 03:14 PM IST"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")
    

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
    
    var h3 = document.createElement("h3")
    h3.innerText = "INDIA NEWS"
    h3.style.color = "#00b1cd"

    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
    p.setAttribute("class","center_heading")

  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
    
    
    var p1 = document.createElement("p")
    p1.innerText = ele.date_time
    p1.style.color = "#757575"
  
    right_side_subdiv.append(h3,p,img,p1)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#center").append(right_side_div)
  })

 