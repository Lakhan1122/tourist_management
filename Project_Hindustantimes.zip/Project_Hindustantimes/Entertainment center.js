//imp this is entire one section like in pic

var h4 = document.createElement("h4")
h4.innerText = "MOST POPULAR"
h4.setAttribute("class","main_heading")
document.querySelector("#center").append(h4)


 
//   one sub div created
var arr1 =[]         //subdiv right 
var right_side = {
heading: "Katrina Kaif shares steamy picture with Vicky Kaushal; Priyanka Chopra showers love; Hrithik Roshan says, 'so nice'",
image:"https://images.hindustantimes.com/img/2022/05/07/550x309/kat_1651897945541_1651897957746.png",
date_time:"Published on May 07, 2022 03:14 PM IST"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")
    

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
    
    var h3 = document.createElement("h3")
    h3.innerText = "BOLLYWOOD"
    h3.style.color = "#00b1cd"

    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
    p.setAttribute("class","center_heading")

  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
    
    
    var p1 = document.createElement("p")
    p1.innerText = ele.date_time
    p1.style.color = "#757575"
  
    right_side_subdiv.append(h3,p,img,p1)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#center").append(right_side_div)
  })
                //--------------------
                var arr1 =[]         //subdiv right 
                var right_side = {
                heading: "Yuvvika Chaudhary is still “waiting” for her potential as an actor to be tapped",
                image:"https://images.hindustantimes.com/img/2022/05/07/550x309/d99983f4-cdd5-11ec-8ffc-07511f5657a1_1651908253314.jpg",
                date_time:"Published on May 07, 2022 03:14 PM IST"
                };
                arr1.push(right_side)
                
                arr1.forEach(function (ele){
                    var right_side_div = document.createElement("div")
                    right_side_div.setAttribute("class","maindiv_shadow")
                    
                
                    var right_side_subdiv = document.createElement("div")
                    right_side_subdiv.setAttribute("class","div_shadow")
                    
                    var h3 = document.createElement("h3")
                    h3.innerText = "BOLLYWOOD"
                    h3.style.color = "#00b1cd"
                
                    var p = document.createElement("p")
                    p.innerText = ele.heading
                    p.setAttribute("class","latest_news_heading")
                    p.setAttribute("class","center_heading")
                
                  
                    var img = document.createElement("img")
                    img.setAttribute("src",ele.image) 
                    img.setAttribute("class","right_1_big_img")
                    
                    
                    var p1 = document.createElement("p")
                    p1.innerText = ele.date_time
                    p1.style.color = "#757575"
                  
                    right_side_subdiv.append(h3,p,img,p1)
                    right_side_div.append(right_side_subdiv)
                    document.querySelector("#center").append(right_side_div)
                  })

                  var arr1 =[]         //subdiv right 
var right_side = {
heading: "Deepika Padukone, Katrina Kaif wish Ranbir Kapoor-Alia Bhatt on their wedding",
image:"https://images.hindustantimes.com/img/2022/04/15/550x309/deepika-katrina-wish-ranbir_1649986842342_1649986861677.jpg",
date_time:"Published on May 07, 2022 03:14 PM IST"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")
    

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
    
    var h3 = document.createElement("h3")
    h3.innerText = "BOLLYWOOD"
    h3.style.color = "#00b1cd"

    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
    p.setAttribute("class","center_heading")

  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
    
    
    var p1 = document.createElement("p")
    p1.innerText = ele.date_time
    p1.style.color = "#757575"
  
    right_side_subdiv.append(h3,p,img,p1)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#center").append(right_side_div)
  })
  var arr1 =[]         //subdiv right 
var right_side = {
heading: "Bobby Deol says him being called unprofessional was 'unfair fabrication'",
image:"https://images.hindustantimes.com/img/2022/05/07/550x309/bobby_deol_1645041507047_1651917698495.jpg",
date_time:"Published on May 07, 2022 03:14 PM IST"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")
    

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
    
    var h3 = document.createElement("h3")
    h3.innerText = "BOLLYWOOD"
    h3.style.color = "#00b1cd"

    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
    p.setAttribute("class","center_heading")

  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
    
    
    var p1 = document.createElement("p")
    p1.innerText = ele.date_time
    p1.style.color = "#757575"
  
    right_side_subdiv.append(h3,p,img,p1)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#center").append(right_side_div)
  })

 //----------==============------------------one category done

 var h4 = document.createElement("h4")
h4.innerText = "DON'T MISS"
h4.setAttribute("class","main_heading")
document.querySelector("#center").append(h4)


 
//   one sub div created
var arr1 =[]         //subdiv right 
var right_side = {
heading: "Aamir Khan and Ranbir Kapoor to come together for Anurag Basu's film? Here's what the filmmaker has to say",
image:"https://images.hindustantimes.com/img/2022/05/07/550x309/amir_khan-ranbir_kapoor_1651925071778_1651925078130.jfif",
date_time:"Published on May 07, 2022 03:14 PM IST"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")
    

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
    
    var h3 = document.createElement("h3")
    h3.innerText = "BOLLYWOOD"
    h3.style.color = "#00b1cd"

    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
    p.setAttribute("class","center_heading")

  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
    
    
    var p1 = document.createElement("p")
    p1.innerText = ele.date_time
    p1.style.color = "#757575"
  
    right_side_subdiv.append(h3,p,img,p1)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#center").append(right_side_div)
  })
                //--------------------
                var arr1 =[]         //subdiv right 
                var right_side = {
                heading: "Madhuri Dixit’s husband Shriram Nene drops her at airport in ₹2 crore Porsche",
                image:"https://images.hindustantimes.com/img/2022/05/07/550x309/madhuri_1651917397957_1651917406673.jpg",
                date_time:"Published on May 07, 2022 03:14 PM IST"
                };
                arr1.push(right_side)
                
                arr1.forEach(function (ele){
                    var right_side_div = document.createElement("div")
                    right_side_div.setAttribute("class","maindiv_shadow")
                    
                
                    var right_side_subdiv = document.createElement("div")
                    right_side_subdiv.setAttribute("class","div_shadow")
                    
                    var h3 = document.createElement("h3")
                    h3.innerText = "BOLLYWOOD"
                    h3.style.color = "#00b1cd"
                
                    var p = document.createElement("p")
                    p.innerText = ele.heading
                    p.setAttribute("class","latest_news_heading")
                    p.setAttribute("class","center_heading")
                
                  
                    var img = document.createElement("img")
                    img.setAttribute("src",ele.image) 
                    img.setAttribute("class","right_1_big_img")
                    
                    
                    var p1 = document.createElement("p")
                    p1.innerText = ele.date_time
                    p1.style.color = "#757575"
                  
                    right_side_subdiv.append(h3,p,img,p1)
                    right_side_div.append(right_side_subdiv)
                    document.querySelector("#center").append(right_side_div)
                  })

                  var arr1 =[]         //subdiv right 
var right_side = {
heading: "Preity Zinta is running towards a healthier version in new video, Hrithik reacts",
image:"https://images.hindustantimes.com/img/2022/05/07/550x309/preity_zinta_hrithik_roshan_1651923328352_1651923334569.jpg",
date_time:"Published on May 07, 2022 03:14 PM IST"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")
    

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
    
    var h3 = document.createElement("h3")
    h3.innerText = "BOLLYWOOD"
    h3.style.color = "#00b1cd"

    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
    p.setAttribute("class","center_heading")

  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
    
    
    var p1 = document.createElement("p")
    p1.innerText = ele.date_time
    p1.style.color = "#757575"
  
    right_side_subdiv.append(h3,p,img,p1)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#center").append(right_side_div)
  })
  var arr1 =[]         //subdiv right 
var right_side = {
heading: "Amrita Rao, RJ Anmol open up on red flags during 5th month of pregnancy, she says: 'Almost half a month I was in stress'",
image:"https://images.hindustantimes.com/img/2022/05/07/550x309/amrita_rao_1650597507477_1651921763537.JPG",
date_time:"Published on May 07, 2022 03:14 PM IST"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")
    

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
    
    var h3 = document.createElement("h3")
    h3.innerText = "HEALTH"
    h3.style.color = "#00b1cd"

    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
    p.setAttribute("class","center_heading")

  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
    
    
    var p1 = document.createElement("p")
    p1.innerText = ele.date_time
    p1.style.color = "#757575"
  
    right_side_subdiv.append(h3,p,img,p1)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#center").append(right_side_div)
  })

 