//imp this is entire one section like in pic

var h4 = document.createElement("h4")
h4.innerText = "IN PICS"
h4.style.textAlign="center"
h4.style.color = "#00b1cd"
document.querySelector("#right").append(h4)


 
//   one sub div created
var arr1 =[]         //1st subdiv right big
var right_side = {
heading: "Kubbra Sait turns muse for designer Amit Aggarwal in multi-coloured drape dress",
image:"https://images.hindustantimes.com/img/2022/05/05/550x309/1_(25)_1651734127239_1651734253967.jpg"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
  
    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
    
  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
  
    right_side_subdiv.append(p,img)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#right").append(right_side_div)
  })
                //--------------------
  var arr1 =[]         //2nd subdiv right big
  var right_side = {
  heading: "Rakul Preet shows how to rock polka-dots this summer through latest pics",
  image:"https://images.hindustantimes.com/img/2022/05/05/550x309/1_(24)_1651726968455_1651726998156.jpg"
  };
  arr1.push(right_side)
  
  arr1.forEach(function (ele){
      var right_side_div = document.createElement("div")
      right_side_div.setAttribute("class","maindiv_shadow")
  
      var right_side_subdiv = document.createElement("div")
      right_side_subdiv.setAttribute("class","div_shadow")
    
      var p = document.createElement("p")
      p.innerText = ele.heading
      p.setAttribute("class","latest_news_heading")
    
      var img = document.createElement("img")
      img.setAttribute("src",ele.image) 
      img.setAttribute("class","right_1_big_img")
    
      right_side_subdiv.append(p,img)
      right_side_div.append(right_side_subdiv)
      document.querySelector("#right").append(right_side_div)
    })

                  //----------------------
    var arr1 =[]         //3rd subdiv right big
var right_side = {
heading: "Sonakshi Sinha is elegance personified in neon crystal saree for Eid 2022",
image:"https://images.hindustantimes.com/img/2022/05/05/550x309/1_(23)_1651722793963_1651722878522.jpg"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
  
    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
  
    right_side_subdiv.append(p,img)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#right").append(right_side_div)
  })

              //--------------------
  var arr1 =[]         //4th subdiv right big
var right_side = {
heading: "Royal Challengers Bangalore vs Chennai Super Kings, IPL 2022: Action in imagesKubbra Sait turns muse for designer Amit Aggarwal in multi-coloured drape dress",
image:"https://images.hindustantimes.com/img/2022/05/04/550x309/PTI05-04-2022-000231B-0_1651686443433_1651686563756.jpg"
};
arr1.push(right_side)

    
arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
  
    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
  
    right_side_subdiv.append(p,img)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#right").append(right_side_div)
  })

              //=-=-=-=-=--=-=-=-=-=-=--
  var arr1 =[]         //5th subdiv right big
  var right_side = {
    heading: "Alia Bhatt shared official pictures from dreamy wedding with Ranbir Kapoor",
    image:"https://images.hindustantimes.com/img/2022/04/14/550x309/Screenshot_2022-04-14_at_73539_PM_1649945171188_1649945420401.png"
    };
    arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
  
    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
  
    right_side_subdiv.append(p,img)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#right").append(right_side_div)
  })


  
  
   //------=========---------========------===== one section i.e.in pic over

//2nd category  TRENDING

//   one sub div created
var h4 = document.createElement("h4")
h4.innerText = "TRENDING"
h4.style.textAlign="center"
h4.style.color = "#00b1cd"
document.querySelector("#right").append(h4)

var arr1 =[]         //1st subdiv right big
  var right_side = {
  heading: "Kitten takes a sip of milk and does this before taking another one. Watch",
  image:"https://images.hindustantimes.com/img/2022/05/06/550x309/human_Kitten_viral_Reddit_video_Food_1651826456711_1651826467122.PNG"
  };
  arr1.push(right_side)
  
  arr1.forEach(function (ele){
      var right_side_div = document.createElement("div")
      right_side_div.setAttribute("class","maindiv_shadow")
  
      var right_side_subdiv = document.createElement("div")
      right_side_subdiv.setAttribute("class","div_shadow")
    
      var p = document.createElement("p")
      p.innerText = ele.heading
      p.setAttribute("class","latest_news_heading")
    
      var img = document.createElement("img")
      img.setAttribute("src",ele.image) 
      img.setAttribute("class","right_1_big_img")
    
      right_side_subdiv.append(p,img)
      right_side_div.append(right_side_subdiv)
      document.querySelector("#right").append(right_side_div)
    })
                  //--------------------
    var arr1 =[]         //2nd subdiv right big
    var right_side = {
    heading: "Dogs enjoy by jumping into pool filled with tennis balls at birthday party. Watch",
    image:"https://images.hindustantimes.com/img/2022/05/06/550x309/Pool_dog_video_Instagram_tennis_ball_birthday_party_1651809795187_1651809800666.PNG"
    };
    arr1.push(right_side)
    
    arr1.forEach(function (ele){
        var right_side_div = document.createElement("div")
        right_side_div.setAttribute("class","maindiv_shadow")
    
        var right_side_subdiv = document.createElement("div")
        right_side_subdiv.setAttribute("class","div_shadow")
      
        var p = document.createElement("p")
        p.innerText = ele.heading
        p.setAttribute("class","latest_news_heading")
      
        var img = document.createElement("img")
        img.setAttribute("src",ele.image) 
        img.setAttribute("class","right_1_big_img")
      
        right_side_subdiv.append(p,img)
        right_side_div.append(right_side_subdiv)
        document.querySelector("#right").append(right_side_div)
      })
  
                    //----------------------
      var arr1 =[]         //3rd subdiv right big
  var right_side = {
  heading: "AR Rahman's daughter Khatija Rahman gets married, she calls it 'most awaited day in my life'. See pics",
  image:"https://images.hindustantimes.com/img/2022/05/06/550x309/khatija-rahman-wedding_1651801105877_1651801139590.jpg"
  };
  arr1.push(right_side)
  
  arr1.forEach(function (ele){
      var right_side_div = document.createElement("div")
      right_side_div.setAttribute("class","maindiv_shadow")
  
      var right_side_subdiv = document.createElement("div")
      right_side_subdiv.setAttribute("class","div_shadow")
    
      var p = document.createElement("p")
      p.innerText = ele.heading
      p.setAttribute("class","latest_news_heading")
    
      var img = document.createElement("img")
      img.setAttribute("src",ele.image) 
      img.setAttribute("class","right_1_big_img")
    
      right_side_subdiv.append(p,img)
      right_side_div.append(right_side_subdiv)
      document.querySelector("#right").append(right_side_div)
    })
  
                //--------------------
    var arr1 =[]         //4th subdiv right big
  var right_side = {
  heading: "The freshest pics in freshest looks from Vicky Kaushal's Instagram",
  image:"https://images.hindustantimes.com/img/2022/04/23/550x309/Screenshot_2022-04-23_at_7.37.17_PM_1650722954647_1650723207027.png"
  };
  arr1.push(right_side)
  
      
  arr1.forEach(function (ele){
      var right_side_div = document.createElement("div")
      right_side_div.setAttribute("class","maindiv_shadow")
  
      var right_side_subdiv = document.createElement("div")
      right_side_subdiv.setAttribute("class","div_shadow")
    
      var p = document.createElement("p")
      p.innerText = ele.heading
      p.setAttribute("class","latest_news_heading")
    
      var img = document.createElement("img")
      img.setAttribute("src",ele.image) 
      img.setAttribute("class","right_1_big_img")
    
      right_side_subdiv.append(p,img)
      right_side_div.append(right_side_subdiv)
      document.querySelector("#right").append(right_side_div)
    })
  
                //=-=-=-=-=--=-=-=-=-=-=--
    var arr1 =[]         //last subdiv right big
    var right_side = {
      heading: "Ashneer Grover reveals if the sharks got ₹10 lakh for each episode of Shark Tank: 'Worked like bonded labour'",
      image:"https://images.hindustantimes.com/img/2022/05/05/550x309/249137016-554745435825272-2858452594078602433-n-1651501394_1651755912112_1651755919067.jpg"
      };
      arr1.push(right_side)
  
  arr1.forEach(function (ele){
      var right_side_div = document.createElement("div")
      right_side_div.setAttribute("class","maindiv_shadow")
  
      var right_side_subdiv = document.createElement("div")
      right_side_subdiv.setAttribute("class","div_shadow")
    
      var p = document.createElement("p")
      p.innerText = ele.heading
      p.setAttribute("class","latest_news_heading")
    
      var img = document.createElement("img")
      img.setAttribute("src",ele.image) 
      img.setAttribute("class","right_1_big_img")
    
      right_side_subdiv.append(p,img)
      right_side_div.append(right_side_subdiv)
      document.querySelector("#right").append(right_side_div)
    })
  