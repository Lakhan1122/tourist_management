###  lookalike of website <span>Hindustan-Times Clone<span>

 <h2>Welcome to this repo</h2>
We are team of 6 members (Praful Telgote, Dhruv Gupta, Chetan Borkar, Lakhan Gurnule, Jitesh Babani,Rupak Tyagi ) has completed the task in 5 days and Given our best efforts to Construct this project.
In case of any suggestion and query feel free to connect us.
 
 
 <h1>TOOLS AND TECHNOLOGY USED ></h1>
  <li>HTML </li>
     <li>css</li>
<li>javascript</li>  
<li>font Awesom icons</li>

### Project Description
 
 <h1>About </h1>
Hindustan Times is an Indian English-language daily newspaper founded by Sunder Singh Lyallpuri, founder-father of 
the Akali movement and the Shiromani Akali Dal in the Punjab Province. It played integral roles in the Indian independence
movement as a nationalist daily.



### Netlify Link
 
https://clonehindustantimesnew.netlify.app/
 
 
 ### Following are the Screenshots for the reference

- *Landing Page*
  ![Landing Page](https://miro.medium.com/max/1400/1*nYIoR5vfWxrYlqTOxy_n8Q.png)

- *Latest-News Page*

  ![Latest-News Page](https://miro.medium.com/max/1400/1*Io_-C6OMIj5LpZUmZ5cOQQ.png)

- *Entertainment-News Page*

  ![Entertainment-News Page](https://miro.medium.com/max/1400/1*8d3OPtup1SSniPahVL3wgg.png)

- *Cities-News Page*

  ![Cities-News Page](https://miro.medium.com/max/1400/1*-xrh3C6cAfgzif86WYaACg.png)

- *Package Page*

  ![Package Page](https://miro.medium.com/max/1400/1*XlR8Hn38w9loOAh1tCJSJA.png)
  

- *Sign-In Page*

  ![Sign-In Page](https://miro.medium.com/max/1400/1*1Tzejvr61v1nWmppVG5Afw.png)



---

### About Project

> We did this project within 5 days in our unit-2 construct week.We have also add some cool functionality in our latest news page where you can surfe latest newses and user can Signup and Login to buy the package.

---


------

### Netlify Link

https://hindustantimesproject.netlify.app
 
------
 <h1>WEBSITE USER FLOW ></h1>

the user flow that we tried to maintain is,
<br/>
home -> login/signup -> dashboard -> get started to news -> create user Id-> Enter email details -> choose package -> payment status.

 <h1>TEAM MEMBERS AND MESSAGE></h1>
we really enjoyed this whole part of developing and had a learing experience and have given our best efforts to bring the BEST thing as POSSIBLE.

### Team Members
- **[Praful Telgote]**
- **[Dhruv Gupta]**
- **[Chetan Borkar])**
- **[Lakhan Gurnule]**
- **[Jitesh Babani]**
- **[Rupak Tyagi]**
---
