//imp this is entire one section like in pic

var h4 = document.createElement("h4")
h4.innerText = "TOP NEWS"
h4.setAttribute("class","main_heading")
document.querySelector("#center").append(h4)


 
//   one sub div created
var arr1 =[]         //subdiv right 
var right_side = {
heading: "'Baseless… untrue': ED on Xiaomi's claims employees faced threats of 'violence'",
image:"https://images.hindustantimes.com/img/2022/05/07/550x309/XIAOMI-RESULTS--1_1651921813352_1651921826494.JPG",
date_time:"Published on May 07, 2022 03:14 PM IST"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")
    

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
    
    var h3 = document.createElement("h3")
    h3.innerText = "INDIA NEWS"
    h3.style.color = "#00b1cd"

    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
    p.setAttribute("class","center_heading")

  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
    
    
    var p1 = document.createElement("p")
    p1.innerText = ele.date_time
    p1.style.color = "#757575"
  
    right_side_subdiv.append(h3,p,img,p1)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#center").append(right_side_div)
  })
                //--------------------
                var arr1 =[]         //subdiv right 
                var right_side = {
                heading: "Centre to set up solar energy panels in all armed police campuses",
                image:"https://images.hindustantimes.com/img/2022/05/07/550x309/6436f59a-cdfa-11ec-a46f-a29bd7e5e767_1651923734174.jpg",
                date_time:"Published on May 07, 2022 03:14 PM IST"
                };
                arr1.push(right_side)
                
                arr1.forEach(function (ele){
                    var right_side_div = document.createElement("div")
                    right_side_div.setAttribute("class","maindiv_shadow")
                    
                
                    var right_side_subdiv = document.createElement("div")
                    right_side_subdiv.setAttribute("class","div_shadow")
                    
                    var h3 = document.createElement("h3")
                    h3.innerText = "DELHI NEWS"
                    h3.style.color = "#00b1cd"
                
                    var p = document.createElement("p")
                    p.innerText = ele.heading
                    p.setAttribute("class","latest_news_heading")
                    p.setAttribute("class","center_heading")
                
                  
                    var img = document.createElement("img")
                    img.setAttribute("src",ele.image) 
                    img.setAttribute("class","right_1_big_img")
                    
                    
                    var p1 = document.createElement("p")
                    p1.innerText = ele.date_time
                    p1.style.color = "#757575"
                  
                    right_side_subdiv.append(h3,p,img,p1)
                    right_side_div.append(right_side_subdiv)
                    document.querySelector("#center").append(right_side_div)
                  })

                  var arr1 =[]         //subdiv right 
var right_side = {
heading: "PBKS vs RR Live Score, IPL 2022: Punjab Kings hope for Livingstone magic after Chahal takes three",
image:"https://images.hindustantimes.com/img/2022/05/07/550x309/bairstow_bcci_1651920650496_1651920662437.jpg",
date_time:"Published on May 07, 2022 03:14 PM IST"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")
    

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
    
    var h3 = document.createElement("h3")
    h3.innerText = "CRICKET NEWS"
    h3.style.color = "#00b1cd"

    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
    p.setAttribute("class","center_heading")

  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
    
    
    var p1 = document.createElement("p")
    p1.innerText = ele.date_time
    p1.style.color = "#757575"
  
    right_side_subdiv.append(h3,p,img,p1)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#center").append(right_side_div)
  })
  var arr1 =[]         //subdiv right 
var right_side = {
heading: "Bobby Deol says him being called unprofessional was 'unfair fabrication'",
image:"https://images.hindustantimes.com/img/2022/05/07/550x309/bobby_deol_1645041507047_1651917698495.jpg",
date_time:"Published on May 07, 2022 03:14 PM IST"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")
    

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
    
    var h3 = document.createElement("h3")
    h3.innerText = "INDIA NEWS"
    h3.style.color = "#00b1cd"

    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
    p.setAttribute("class","center_heading")

  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
    
    
    var p1 = document.createElement("p")
    p1.innerText = ele.date_time
    p1.style.color = "#757575"
  
    right_side_subdiv.append(h3,p,img,p1)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#center").append(right_side_div)
  })

 //----------==============------------------one category done

 var h4 = document.createElement("h4")
h4.innerText = "DON'T MISS"
h4.setAttribute("class","main_heading")
document.querySelector("#center").append(h4)


 
//   one sub div created
var arr1 =[]         //subdiv right 
var right_side = {
heading: "Doctor Strange 2: A list of all surprise Marvel cameos in the film",
image:"https://images.hindustantimes.com/img/2022/05/07/550x309/doctor-strange-in-the-multiverse-of-madness_1651918621970_1651918634894.jpg",
date_time:"Published on May 07, 2022 03:14 PM IST"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")
    

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
    
    var h3 = document.createElement("h3")
    h3.innerText = "HOLLYWOOD NEWS"
    h3.style.color = "#00b1cd"

    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
    p.setAttribute("class","center_heading")

  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
    
    
    var p1 = document.createElement("p")
    p1.innerText = ele.date_time
    p1.style.color = "#757575"
  
    right_side_subdiv.append(h3,p,img,p1)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#center").append(right_side_div)
  })
                //--------------------
                var arr1 =[]         //subdiv right 
                var right_side = {
                heading: "Cyclone likely to miss Odisha-Andhra coast, set to change course on May 10",
                image:"https://images.hindustantimes.com/img/2022/05/07/550x309/650bcc60-cdfb-11ec-a18e-026abbb3bb32_1651924454287.jpg",
                date_time:"Published on May 07, 2022 03:14 PM IST"
                };
                arr1.push(right_side)
                
                arr1.forEach(function (ele){
                    var right_side_div = document.createElement("div")
                    right_side_div.setAttribute("class","maindiv_shadow")
                    
                
                    var right_side_subdiv = document.createElement("div")
                    right_side_subdiv.setAttribute("class","div_shadow")
                    
                    var h3 = document.createElement("h3")
                    h3.innerText = "DELHI NEWS"
                    h3.style.color = "#00b1cd"
                
                    var p = document.createElement("p")
                    p.innerText = ele.heading
                    p.setAttribute("class","latest_news_heading")
                    p.setAttribute("class","center_heading")
                
                  
                    var img = document.createElement("img")
                    img.setAttribute("src",ele.image) 
                    img.setAttribute("class","right_1_big_img")
                    
                    
                    var p1 = document.createElement("p")
                    p1.innerText = ele.date_time
                    p1.style.color = "#757575"
                  
                    right_side_subdiv.append(h3,p,img,p1)
                    right_side_div.append(right_side_subdiv)
                    document.querySelector("#center").append(right_side_div)
                  })

                  var arr1 =[]         //subdiv right 
var right_side = {
heading: "Ex-Pakistan pacer has his say on Rishabh Pant vs Mohammad Rizwan debate",
image:"https://images.hindustantimes.com/img/2022/05/07/550x309/New_Project_-_2022-05-07T151448.956_1651916714815_1651916721938.jpg",
date_time:"Published on May 07, 2022 03:14 PM IST"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")
    

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
    
    var h3 = document.createElement("h3")
    h3.innerText = "CRICKET NEWS"
    h3.style.color = "#00b1cd"

    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
    p.setAttribute("class","center_heading")

  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
    
    
    var p1 = document.createElement("p")
    p1.innerText = ele.date_time
    p1.style.color = "#757575"
  
    right_side_subdiv.append(h3,p,img,p1)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#center").append(right_side_div)
  })
  var arr1 =[]         //subdiv right 
var right_side = {
heading: "Is mask wearing beneficial or causing any harm? Here's what health experts say",
image:"https://images.hindustantimes.com/img/2022/05/07/550x309/victor-he-px9z5Zijwo8-unsplash_1651921788109_1651921809164.jpg",
date_time:"Published on May 07, 2022 03:14 PM IST"
};
arr1.push(right_side)

arr1.forEach(function (ele){
    var right_side_div = document.createElement("div")
    right_side_div.setAttribute("class","maindiv_shadow")
    

    var right_side_subdiv = document.createElement("div")
    right_side_subdiv.setAttribute("class","div_shadow")
    
    var h3 = document.createElement("h3")
    h3.innerText = "HEALTH"
    h3.style.color = "#00b1cd"

    var p = document.createElement("p")
    p.innerText = ele.heading
    p.setAttribute("class","latest_news_heading")
    p.setAttribute("class","center_heading")

  
    var img = document.createElement("img")
    img.setAttribute("src",ele.image) 
    img.setAttribute("class","right_1_big_img")
    
    
    var p1 = document.createElement("p")
    p1.innerText = ele.date_time
    p1.style.color = "#757575"
  
    right_side_subdiv.append(h3,p,img,p1)
    right_side_div.append(right_side_subdiv)
    document.querySelector("#center").append(right_side_div)
  })

 