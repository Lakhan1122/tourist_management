var dataleft=[
    {
     heading:"INDIA NEWS",
     midtxt:"On heatwave ,monsoon,PM Modi set to chair key meeting on preparedness: Reports",
     RelTime:"Updated on May 05 01:17PM IST"
    },
    {
     heading:"INDIA NEWS",
     midtxt:"J&K delimation panel's tenure ends tomorrow, likely to submit draft report ",
     RelTime:"Published in May 05 12:20PM IST"
    },
    {
     heading:"PATNA NEWS",
     midtxt:"Prasant Kishor says no political party now, annnounces 'padyatra' from Oct 2",
     RelTime:"Published on May 05 12:20PM IST"
    },
    {
      heading:"INDIA NEWS",
      midtxt:"Ukaraine,global food crisis, defence partnership undercore India-France talks ",
      RelTime:"Published on May 05 01:09PM IST"  
    },
    {
      heading:"INDIA NEWS",
      midtxt:"Stalin's 5 announcements to mark 1 year as Tamil Nadu chief minister  ",
      RelTime:"Updated on May 05 01:17PM IST"
     },
     {
      heading:"WORLD NEWS",
      midtxt:"Emergency in Sri Lanka, Nepal, Pak forex dips, South Asia in crisis",
      RelTime:"Published in May 05 12:20PM IST"
     },
     {
      heading:"BOLLYWOOD",
      midtxt:"Katrina Kaif shares steamy pool pic with Vicky Kaushal: 'Me and mine'",
      RelTime:"Published on May 05 12:20PM IST"
     },
     {
       heading:"WEB-SERIES",
       midtxt:"Lock Upp day 68: Saisha Shinde evicted; Munawar Faruqui tells her 'I love you' ",
       RelTime:"Published on May 05 01:09PM IST"  
     },
     {
      heading:"CRICKET",
      midtxt:"Cricket legends slam Rohit Sharma's tactic after MI's twin wins in IPL 2022",
      RelTime:"Updated on May 05 01:17PM IST"
     },
     {
      heading:"WORLD NEWS",
      midtxt:"Emergency in Sri Lanka, Nepal, Pak forex dips, South Asia in crisis",
      RelTime:"Published in May 05 12:20PM IST"
     },
     {
      heading:"BOLLYWOOD",
      midtxt:"Katrina Kaif shares steamy pool pic with Vicky Kaushal: 'Me and mine'",
      RelTime:"Published on May 05 12:20PM IST"
     },
     {
       heading:"CRICKET",
       midtxt:"Cricket legends slam Rohit Sharma's tactic after MI's twin wins in IPL 2022",
       RelTime:"Published on May 05 01:09PM IST"  
     },
]

var datamid=[
    {
      heading:"BOARD EXAMS",
      maintxt:"CBSE Class 10 Maths Term 2 Exam 2022:What students said after mathematics paper",
      reldate:"Published on May 05,2022 01:13PM IST",
      logo:"",
      img:"https://images.hindustantimes.com/img/2022/05/05/148x111/CBSE_Class_10_Maths_paper_2022_1651736483459_1651736483605.jpg"
    },
    {
      heading:"BOLLYWOOD",
      maintxt:"Jayeshbhai Jordar faces PIL in Delhi plea seeks delation of this scene",
      reldate:"Published on May 05,2022 01:11PM IST",
      logo:"",
      img:"https://images.hindustantimes.com/img/2022/05/05/148x111/ranveer_jayeshbhai_1651728537020_1651728544264.JPG"
    },
    {
      heading:"COMPETATIVE EXAMS",
      maintxt:"UPPSC Veterinary MO Admit Card 2020 released, download link here",
      reldate:"Published on May 05,2022 01:10PM IST",
      logo:"",
      img:"https://images.hindustantimes.com/img/2022/05/05/148x111/d8e0361e-bb5c-11ec-9902-472e44f2ebef_1649877249271_1651736326085.jpg"
    },
    {
      heading:"SPONSORED",
      maintxt:"From T-Homes to DidiTown :The journey of 'Digital Housing' in Indian Real Estate",
      reldate:"Published on Apr 26,2022 12:38PM IST",
      logo:"",
      img:"https://tpc.googlesyndication.com/simgad/8292573116992183745?"
    },
    {
      heading:"INDIA NEWS",
      maintxt:"Ukraine ,global food crisis ,defence partnership undescore India-France talks",
      reldate:"Published on May 05,2022 01:09PM IST",
      logo:"",
      img:"https://images.hindustantimes.com/img/2022/05/05/150x84/24a71eec-cc46-11ec-a18e-026abbb3bb32_1651736391015.jpg"  
     },
     {
      heading:"INDIA NEWS",
      maintxt:"5 people killed, 4 injured in auto rickshaw -truck collison in Madhya Pradesh",
      reldate:"Published on May 05,2022 01:08PM IST",
      logo:"",
      img:"https://images.hindustantimes.com/img/2022/05/05/148x111/35da502e-c4c8-11ec-8b2d-b6dbe1b60323_1650994906078_1651736074027.jpg",
     },
     {
       heading:"HEALTH AND BEAUTY",
       maintxt:"Amazon summer sale 2022 :Get up to 50% discount on haircare products ",
       reldate:"Published on May 05,2022 01:04PM IST",
       logo:"",
       img:"https://images.hindustantimes.com/img/2022/05/05/148x111/amazon_summer_sale_on_haircare_products_1651732556385_1651732574149.jpg"
     },
     {
       heading:"NEWS",
       maintxt:"'Art 370 removal a slap':Al-Qaeda slams Arab states for backing India on J&K",
       reldate:"published on May 05,2022 01:03 PM IST",
       logo:"",
       img:"https://images.hindustantimes.com/img/2022/05/05/148x111/HT_Normal_Thumbnail_-_AUG__2021_-_2022-05-05T125119.555_1651735901231_1651735906173.jpg",
     },
     {
       heading:"CRICKET",
       maintxt:"MS Dhoni minces no words, blames batters for CSK's 13-run losss to RCB",
       reldate:"Published on May 05,2022 12:58PM IST",
       logo:"",
       img:"https://images.hindustantimes.com/img/2022/05/05/148x111/PTI04-21-2022-000299A-0_1651735507103_1651735542621.jpg"
     },
     {
       heading:"INDIA NEWS",
       maintxt:"Afternoon brief: Amit Shah arrives in West Bengal on two-day visit",
       reldate:"Published on May 05,2022 12:55 PM IST",
       logo:"",
       img:"https://images.hindustantimes.com/img/2022/05/05/148x111/d2c7fed6-b749-11ec-a4f3-fc37f02059fa_1649528463874_1651735406307.jpg" 
      },
      {
        heading:"JAIPUR NEWS",
        maintxt:"Amid tensions, internet services suspended in Rajasthan's Bhilwara",
        reldate:"Published on May 05,2022 12:50PM IST",
        logo:"",
        img:"https://images.hindustantimes.com/img/2022/05/05/150x84/4ebc7a0e-cc43-11ec-8ffc-07511f5657a1_1651735250887.jpg"
      },
      {
        heading:"BRAND STORIES",
        maintxt:"Is your child flu-safe this summer?",
        reldate:"Published on May 05,2022 12:50PM IST",
        logo:"",
        img:"https://images.hindustantimes.com/img/2022/05/05/148x111/20220505_123932_0000_1651735070882_1651735081620.jpg",
      },
       {
         heading:"EMPLOYMENT NEWS",
         maintxt:"BSF Group B Recruitment 2022 :Apply for 90 SI,JE and Inspector posts",
         reldate:"Published on May 05,2022 12:45PM IST",
         logo:"",
         img:"https://images.hindustantimes.com/img/2022/05/05/148x111/BSF_1651734786576_1651734795668.png"
       },
       {
         heading:"LIFESTYLE",
         maintxt:"Kubbra Sait turns muse for designer Amit Aggarwal in multi-coloured drape dress",
         reldate:"Updated on May 05, 2022 12:41 PM IST",
         logo:"",
         img:"https://images.hindustantimes.com/img/2022/05/05/148x111/1_(25)_1651734127239_1651734254043.jpg"
       },
]

var dataright=[
  {
    txt:"Kubbra Sait turns muse for designer Amit Aggarwal in multi-coloured drape dress",
    Rimg:"https://images.hindustantimes.com/img/2022/05/05/148x111/1_(25)_1651734127239_1651734254043.jpg"
  },
  {
    txt:"Rakul Preet shows how to rock polka-dots this summer through latest pics",
    Rimg:"https://images.hindustantimes.com/img/2022/05/05/148x111/1_(24)_1651726968455_1651726998214.jpg"
  
  },
  {
    txt:"Sonakshi Sinha is elegance personified in neon crystal saree for Eid 2022",
    Rimg:"https://images.hindustantimes.com/img/2022/05/05/148x111/1_(23)_1651722793963_1651722878522.jpg"
  },
  {
    txt:"Kubbra Sait turns muse for designer Amit Aggarwal in multi-coloured drape dress",
    Rimg:"https://images.hindustantimes.com/img/2022/05/05/148x111/1_(25)_1651734127239_1651734254043.jpg"
  },
  {
    txt:"Rakul Preet shows how to rock polka-dots this summer through latest pics",
    Rimg:"https://images.hindustantimes.com/img/2022/05/05/148x111/1_(24)_1651726968455_1651726998214.jpg"
  
  },
  {
    txt:"Sonakshi Sinha is elegance personified in neon crystal saree for Eid 2022",
    Rimg:"https://images.hindustantimes.com/img/2022/05/05/148x111/1_(23)_1651722793963_1651722878522.jpg"
  }
]

var dataright2=[
  {
    txt:"Supriya Pathak spills the beans about her web show, dream home and film family",
    Rimg:"https://images.hindustantimes.com/img/2022/05/05/148x111/HT_Normal_Thumbnail_-_AUG__2021_1651717491505_1651717496186.jpg"
  },
  {
    txt:"India's maritime security gets more teeth; ICG inducts ALH MK III chopper",
    Rimg:"https://images.hindustantimes.com/img/2022/05/05/148x111/HT_Normal_Thumbnail_-_AUG__2021_-_2022-05-05T002301.773_1651716821826_1651716825146.jpg"
  
  },
  {
    txt:"'Modi Modi' chants in Paris as PM gets rousing reception from Indian Community",
    Rimg:"https://images.hindustantimes.com/img/2022/05/05/148x111/HT_Normal_Thumbnail_-_AUG__2021jkgjgj_(13)_1651716209864_1651716213717.jpg"
  },
  {
    txt:"Supriya Pathak spills the beans about her web show, dream home and film family",
    Rimg:"https://images.hindustantimes.com/img/2022/05/05/148x111/HT_Normal_Thumbnail_-_AUG__2021_1651717491505_1651717496186.jpg"
  },
  {
    txt:"India's maritime security gets more teeth; ICG inducts ALH MK III chopper",
    Rimg:"https://images.hindustantimes.com/img/2022/05/05/148x111/HT_Normal_Thumbnail_-_AUG__2021_-_2022-05-05T002301.773_1651716821826_1651716825146.jpg"
  
  },
 
]


var main=document.createElement("div");
main.setAttribute("id","main"); 

var left=document.createElement("div");
left.setAttribute("id","left");

dataleft.forEach(function(el){

  var leftdiv=document.createElement("div")
  leftdiv.setAttribute("id","lfdiv")

  var H3=document.createElement("h3");
  H3.innerText=el.heading

  var p=document.createElement("p");
  p.innerText=el.midtxt

  var p1=document.createElement("p");
  p1.innerText=el.RelTime;

  leftdiv.append(H3,p,p1);
  left.append(leftdiv);
})
  

var mid=document.createElement("div");
mid.setAttribute("id","mid");


datamid.forEach(function(ele){

  var box=document.createElement("div");
  box.setAttribute("id","box");

  
  div1=document.createElement("div");
  div1.setAttribute("id","div1")
  div2=document.createElement("div");
  div2.setAttribute("id","div2");
    
  var H3=document.createElement("h3")
  H3.innerText=ele.heading;

  var H4=document.createElement("h4");
  H4.innerText=ele.maintxt

  var p2=document.createElement("p");
  p2.innerText=ele.reldate;

  var imgt=document.createElement("img");
  imgt.setAttribute("src",ele.img);

  div1.append(H3,H4,p2);
  div2.append(imgt);
  box.append(div1,div2);
  mid.append(box);
})




var right=document.createElement("div");
right.setAttribute("id","right");
 
var pt1=document.createElement("div");

var H3=document.createElement("h3");
H3.innerText="Follow these golden rules to prevent bloating post meals"

var IMG=document.createElement("img");
IMG.setAttribute("src","https://images.hindustantimes.com/img/2022/05/05/550x309/bloating_thumb_1651755725244_1651755756096.jpg")
IMG.setAttribute("id","IMG")

pt1.append(H3,IMG);
right.append(pt1);

dataright.forEach(function(elem){

  var Rdiv=document.createElement("div");
  Rdiv.setAttribute("id","Rdiv")
  
  var p3=document.createElement("p");
  p3.innerText=elem.txt

  var Rimg=document.createElement("img");
  Rimg.setAttribute("src",elem.Rimg)

  Rdiv.append(p3,Rimg);
  right.append(Rdiv);
})
var btndiv=document.createElement("div");
btndiv.setAttribute("id","btndiv")
var viewbut=document.createElement("button");
viewbut.innerText="View All >"

btndiv.append(viewbut);
right.append(btndiv);

var pt2=document.createElement("div");

var H3=document.createElement("h3");
H3.innerText="BSF unearths Pakistani 'tunnel' near International Border in J&K's Samba"

var IMG=document.createElement("img");
IMG.setAttribute("src","https://images.hindustantimes.com/img/2022/05/05/550x309/HT_Normal_Thumbnail_-_AUG__2021-2_1651719503887_1651719509393.jpg")
IMG.setAttribute("id","IMG2")

pt2.append(H3,IMG);
right.append(pt2);

var pt3=document.createElement("div");

var H3=document.createElement("h3");
H3.innerText="Doctor Strange 2 box office: Another win for Hollywood in India, earns ₹27 cr"

var IMG=document.createElement("img");
IMG.setAttribute("src","https://images.hindustantimes.com/img/2022/05/07/550x309/doctor_strange_2_box_office_1651900264047_1651900264257.jpeg")
IMG.setAttribute("id","IMG2")

pt2.append(H3,IMG);
right.append(pt3);

dataright2.forEach(function(elem){

  var Rdiv=document.createElement("div");
  Rdiv.setAttribute("id","Rdiv")
  
  var p3=document.createElement("p");
  p3.innerText=elem.txt

  var Rimg=document.createElement("img");
  Rimg.setAttribute("src",elem.Rimg)

  Rdiv.append(p3,Rimg);
  right.append(Rdiv);
})
var pt4=document.createElement("div");

var H3=document.createElement("h3");
H3.innerText="KGF Chapter 2 box office collection: Yash-starrer’s Hindi version earns ₹400 crore; second ‘Hindi film’ ever to do so"

var IMG=document.createElement("img");
IMG.setAttribute("src","https://images.hindustantimes.com/img/2022/05/06/257x145/kgf-2_1651846655638_1651846666374.webp")
IMG.setAttribute("id","IMG2")

pt2.append(H3,IMG);
right.append(pt4);





main.append(left,mid,right);
document.querySelector("body").append(main);



var naam = localStorage.getItem("name1")

var myac = document.querySelector(".myac")

  if(naam!=""){
    myac.innerHTML=naam
  }

